import menu_inicial  # Se importa el menú
if __name__ == "__main__":
    # El programa inicia con lista vacía,
    # Pero de igual forma se deja en el archivo json registros resultado de pruebas realizadas
    clientes = []
    menu_inicial.ejecutar(clientes)